/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.card.spellcard;

import model.OnBoard;
import model.card.HeroCard;
import model.card.SpellCard;
import model.type.SpellTarget;

/**
 *
 * @author mew3d
 */
public class TalentedHealer extends SpellCard{

    public TalentedHealer() {
        super("Talented_Healer", 2, "Heal all allies by 1.", SpellTarget.NONE);
    }

    @Override
    public void cast(HeroCard target) {
        HeroCard[] handle = OnBoard.getBoard().getActivePlayer().getOffHandle();
        for(HeroCard card: handle){
            card.setDefendPoint(card.getDefendPoint() + 1);
        }
        System.out.println("Your team have been increase 1 defend point.");
    }
    
}
