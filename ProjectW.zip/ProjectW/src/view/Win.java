package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Win extends JFrame {
    
    private String winner;
    
    private JPanel panel_paint = new JPanel() {
        @Override
        public void paintComponent(Graphics g){
            super.paintComponent(g);
            Image img_background = new ImageIcon(getClass().getResource("/view/image/Champion.jpg")).getImage();
            g.drawImage(img_background, 0, 0, 500, 500, null); // drawing img_background
            g.setFont(new Font("Arial", Font.BOLD, 30));
            g.setColor(Color.yellow);
            g.drawString("Congratulations to the winner!", 27, 140);
            g.setFont(new Font("Arial", Font.BOLD, 45));
            g.drawString(winner, 150, 185);
        }
    };

    public Win(String name) {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setSize(500, 500);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.winner = name;
        panel_paint.setBounds(0, 0, this.getWidth(), this.getHeight());
        panel_paint.repaint();
        this.add(panel_paint);
    }

    public void run() {
        this.setVisible(true);
    }
}
