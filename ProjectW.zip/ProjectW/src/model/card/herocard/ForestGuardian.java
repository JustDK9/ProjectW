package model.card.herocard;

import model.card.HeroCard;

public class ForestGuardian extends HeroCard {
    public ForestGuardian() {
        super("ForestGuardian", 3, "A protector of the enchanted forest.", 4, 5);
    }
}