package controller;

import java.util.ArrayList;
import java.util.List;

public class Tools {

    public static String[] wrapText(String text, int maxWidth, int descriptHeight) {
        if (text == null || text.isEmpty()) {
            return new String[]{"", "", ""}; // Trả về mảng 3 dòng trống
        }

        String[] words = text.split(" "); // Tách chuỗi thành từng từ
        StringBuilder currentLine = new StringBuilder();
        List<String> wrappedLines = new ArrayList<>();

        for (String word : words) {
            // Kiểm tra xem thêm từ mới có vượt quá maxWidth không
            if (currentLine.length() + word.length() + 1 > maxWidth) {
                wrappedLines.add(currentLine.toString().trim()); // Thêm dòng hiện tại vào danh sách và xóa khoảng trắng
                currentLine = new StringBuilder(word); // Bắt đầu dòng mới với từ hiện tại
            } else {
                if (currentLine.length() > 0) {
                    currentLine.append(" "); // Thêm khoảng trắng nếu không phải từ đầu dòng
                }
                currentLine.append(word); // Thêm từ vào dòng hiện tại
            }
        }

        // Thêm dòng cuối cùng nếu có nội dung
        if (currentLine.length() > 0) {
            wrappedLines.add(currentLine.toString().trim());
        }

        // Đảm bảo có 3 dòng
        while (wrappedLines.size() < descriptHeight) {
            wrappedLines.add(""); // Thêm dòng trống nếu chưa đủ descriptHeight dòng
        }

        // Chỉ lấy descriptHeight dòng đầu tiên nếu có nhiều hơn
        return wrappedLines.subList(0, Math.min(wrappedLines.size(), descriptHeight)).toArray(new String[0]); // Chuyển đổi danh sách thành mảng và trả về
    }

    public static String centerAlign(String text, int totalWidth) {
        int textLength = text.length();
        if (textLength >= totalWidth) {
            return text; // Trả về văn bản gốc nếu nó lớn hơn chiều rộng tổng
        }

        int totalPadding = totalWidth - textLength;
        int paddingLeft = totalPadding / 2; // Padding bên trái
        int paddingRight = totalPadding - paddingLeft; // Padding bên phải

        // Tạo chuỗi khoảng trắng
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < paddingLeft; i++) {
            sb.append(" ");
        }
        sb.append(text);
        for (int i = 0; i < paddingRight; i++) {
            sb.append(" ");
        }

        return sb.toString();
    }
}
