package model.card.herocard;

import model.card.HeroCard;

/**
 *
 
@author Vo Hoang*/
public class ForestGuardianElf extends HeroCard {
    public ForestGuardianElf() {
        super("ForestGuardianElf", 3, "A wise elf protector of the ancient forest and its secrets.", 3, 5);
    }
}