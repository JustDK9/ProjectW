package model.card;

import controller.Tools;
import model.type.SpellTarget;

public abstract class SpellCard extends Card {

    private SpellTarget spellTarget;

    public SpellCard(String name, int price, String desctiption, SpellTarget spellTarget) {
        super(name, price, desctiption);
        this.spellTarget = spellTarget;
    }

    public SpellTarget getSpellTarget() {
        return spellTarget;
    }

    public void setSpellTarget(SpellTarget spellTarget) {
        this.spellTarget = spellTarget;
    }

    public abstract void cast(HeroCard target);

    @Override
    public void display() {
        int cardWidth = 19; // Chiều rộng của thẻ
        String greenColor = "\u001B[32m"; // Mã màu xanh lá cây
        String resetColor = "\u001B[0m"; // Đặt lại màu mặc định

        // Đường viền với màu xanh lá cây
        String line = greenColor + "|=================|" + resetColor;
        System.out.println(line);

        // Tiêu đề thẻ với giá
        String stars = "*".repeat(super.getPrice()); // Tạo chuỗi dấu tương ứng với giá
        String title = " Spell" + " ".repeat(17-5-super.getPrice()-2) + stars + " "; // Sử dụng chuỗi dấu *

        System.out.println(greenColor + "|" + Tools.centerAlign(title, cardWidth - 2) + "|" + resetColor);
        System.out.println(line);

        // Tên anh hùng
        System.out.println(greenColor + "|" + Tools.centerAlign(getName(), cardWidth - 2) + "|" + resetColor);
        System.out.println(line);

        // Hiển thị khả năng
        String ability = super.getDesctiption(); // Assuming SpellTarget is an enum, use name() to get the enum value
        String[] abilityLines = Tools.wrapText(ability, cardWidth - 2, 5); // Đặt độ rộng tối đa cho ability

        // Giới hạn số dòng hiển thị ở 5
        int maxLines = 5;
        for (int i = 0; i < Math.min(abilityLines.length, maxLines); i++) {
            // Căn giữa cho nội dung khả năng
            System.out.println(greenColor + "|" + Tools.centerAlign(abilityLines[i], cardWidth - 2) + "|" + resetColor);
        }

        // Nếu có nhiều hơn 5 dòng, thêm thông báo
        if (abilityLines.length > maxLines) {
            System.out.println(greenColor + "|" + Tools.centerAlign("...(More)", cardWidth - 2) + "|" + resetColor);
        }

        System.out.println(line); // Kết thúc thẻ
    }

}
