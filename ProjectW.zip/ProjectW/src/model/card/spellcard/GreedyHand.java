package model.card.spellcard;

import model.OnBoard;
import model.card.Deck;
import model.card.HeroCard;
import model.card.SpellCard;
import model.type.SpellTarget;

/**
 *
 * @author mew3d
 */
public class GreedyHand extends SpellCard{

    public GreedyHand() {
        super("Greedy Hand", 2, "Draw 2 card.", SpellTarget.NONE);
    }

    @Override
    public void cast(HeroCard target) {
        Deck handle = OnBoard.getBoard().getActivePlayer().getHandle();
        handle.addCard(OnBoard.getBoard().getMainDeck().withdrawTopCard());
        handle.addCard(OnBoard.getBoard().getMainDeck().withdrawTopCard());
        System.out.println("this");
    }
    
}
