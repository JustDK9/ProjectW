package model.functional.abilities;

import model.card.Card;

public class Blessing extends Abilities{

    public Blessing() {
    }

    @Override
    public void action(Card target) {
        System.out.println("blessing");
    }
    
}
