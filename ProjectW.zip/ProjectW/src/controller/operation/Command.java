package controller.operation;

import controller.operation.GamePlay;
import model.OnBoard;
import model.Player;

public class Command {

    private GamePlay gameplay = new GamePlay();
    private Player player = new Player();

    public void Command(String command, int chooseCardPo1, int chooseCardPo2) {
        switch (command) {
            case "at" -> {
                /* 1. Chọn hero trên sàn của mình và chọn hero của đối thủ để tấn công */
                //OnBoard.getBoard().getActivePlayer().getOffHandle().get(chooseCardPo1);

            }
            default -> {
                /*Sai cu phap */

            }
        }
    }

    public void Command(String command, int chooseCardPo1) {
        switch (command) {
            case "eq" -> {
                /* 2. Chọn hero trên sân và cộng chỉ số trực tiếp vào máu và hp. Thêm nội tại */
            }
            case "rm" -> {
                /* 3. Xoa bai cam tren tay */
            }
            default -> {
                /*Sai cu phap */
            }
        }
    }

    public void Command(String command) {
        if (command.equals("end")) {
            gameplay.swap(OnBoard.getBoard().getActivePlayer(), OnBoard.getBoard().getOpponentPlayer());
        }
    }

    public void Commmand(String command) {
        if (command.equals("/help")) {
            System.out.println("|======|===========================================|");
            System.out.println("|  at  | your hero position + enemy's hero position|");
            System.out.println("|======|===========================================|");
            System.out.println("|  eq  |     your hero or enemy's position or 0    |");
            System.out.println("|======|===========================================|");
            System.out.println("|  rm  |          remove your hadling card         |");
            System.out.println("|======|===========================================|");
            System.out.println("| end  |               End your turn               |");
            System.out.println("|======|===========================================|");
        }
    }

}
