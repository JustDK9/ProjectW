/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.card.spellcard;

import java.util.ArrayList;
import model.OnBoard;
import model.card.HeroCard;
import model.card.SpellCard;
import model.type.SpellTarget;

/**
 *
 * @author mew3d
 */
public class GreatCommmander extends SpellCard{

    public GreatCommmander(String name, int price, String desctiption, SpellTarget option) {
        super("Great Commander", 2, "Increase allies attack point by 1.", SpellTarget.NON);
    }

    @Override
    public void cast(HeroCard target) {
        ArrayList<HeroCard> handle = OnBoard.getBoard().getActivePlayer().getOffHandle();
        for(HeroCard card: handle){
            card.setAttackPoint(card.getAttackPoint() + 1);
        }
        System.out.println("Your team have been increase 1 attack point.");
    }
    
}
