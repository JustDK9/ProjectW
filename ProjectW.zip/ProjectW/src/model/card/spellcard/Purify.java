/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.card.spellcard;

import model.card.HeroCard;
import model.card.SpellCard;
import model.type.SpellTarget;

/**
 *
 * @author mew3d
 */
public class Purify extends SpellCard{

    public Purify() {
        super("Purify", 2, "Clear effect for a ally hero", SpellTarget.ACTIVE);
    }

    @Override
    public void cast(HeroCard target) {
        target.setEffect(null);
        System.out.println(target.getName() + " have been clear all effects.");
    }
    
}
