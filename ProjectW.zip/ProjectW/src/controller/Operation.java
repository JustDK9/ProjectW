package controller;

import model.OnBoard;
import model.Player;
import model.type.TurnQueue;
import view.Win;

public class Operation {

    private Player player1 = new Player();
    private Player player2 = new Player();
    DefaultGUI gui_player1 = new DefaultGUI(player1, player2);
    DefaultGUI gui_player2 = new DefaultGUI(player2, player1);
    public static int turn = 0;
    
    public void getName() {
        player1.setName("1st Player");
        player2.setName("2nd Player");
    }

    public void openFrame() {
        gui_player1.run();
        gui_player2.run();
    }

    public void gameSetUp() {
        OnBoard.getBoard().getMainDeck().shuffle();
        for(int i = 0; i < 5; i++){           
            player1.getHandle().addCard(OnBoard.getBoard().getMainDeck().withdrawTopCard());
            player2.getHandle().addCard(OnBoard.getBoard().getMainDeck().withdrawTopCard());
        }
        player1.setQueue(TurnQueue.ACTIVE);
        player2.setQueue(TurnQueue.OPPONENT);
    }
    
    public static boolean updateSignal = true; //calling after active an button in default gui
    public static boolean endSignal = false;
    
    public void updating() {
        gui_player1.updating();
        gui_player2.updating();       
        if(player1.getHealthPoint() * player2.getHealthPoint() <= 0){
            endSignal = true;
            player1.setQueue(TurnQueue.OPPONENT);
            player2.setQueue(TurnQueue.OPPONENT);
            gui_player1.dispose();
            gui_player2.dispose();
        }
    }
    
    public String getWinner() {
        return player1.getHealthPoint() <= 0 ? player2.getName() : player1.getName();
    }
    
    public static void main(String[] args) {
        Operation op = new Operation();
        op.getName();
        op.gameSetUp();
        op.openFrame();
        while (!endSignal){
            if(updateSignal){
                op.updating(); 
                updateSignal = false;             
            }       
            try {
                Thread.sleep(400);
            } catch (InterruptedException ex) {
                System.out.println("sleep fail!");
            }
        }
        
        new Win(op.getWinner()).run();
    }
}
