package model.functional.abilities;

import model.OnBoard;
import model.card.Card;
import model.card.Deck;


public class Add2Card extends Abilities{

    public Add2Card() {
    }

    @Override
    public void action(Card target) {
        Deck handle = OnBoard.getBoard().getActivePlayer().getHandle();
        handle.addCard(OnBoard.getBoard().getMainDeck().randomizeWithdrawCard());
        handle.addCard(OnBoard.getBoard().getMainDeck().randomizeWithdrawCard());
        System.out.println("this");
    }
    
}
