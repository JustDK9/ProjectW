package controller;

import model.OnBoard;
import model.Player;
import model.type.TurnQueue;

public class Operation {

    private Player player1 = new Player();
    private Player player2 = new Player();
    DefaultGUI gui_player1 = new DefaultGUI(player1, player2);
    DefaultGUI gui_player2 = new DefaultGUI(player2, player1);
    
    public void getName() {
        player1.setName("p1");
        player2.setName("p2");
    }

    public void openFrame() {
        player1.setInTurn(true);
        gui_player1.run();
        gui_player2.run();
    }

    public static void switchTurn(Player owned, Player opponent) {
        owned.setInTurn(!owned.isInTurn()); // set queue = opponent
        opponent.setInTurn(!opponent.isInTurn()); // set queue = active
    }

    public void gameSetUp() {
        OnBoard.getBoard().getMainDeck().shuffle();
        for(int i = 0; i < 5; i++){           
            player1.getHandle().addCard(OnBoard.getBoard().getMainDeck().withdrawTopCard());
            player2.getHandle().addCard(OnBoard.getBoard().getMainDeck().withdrawTopCard());
        }
        player1.setQueue(TurnQueue.ACTIVE);
        player2.setQueue(TurnQueue.OPPONENT);
    }

    public void runGame() {
        try {
            gui_player1.updating();
            gui_player2.updating();
            Thread.sleep(1000);
        } catch (Exception e) {
            System.out.println("updating error");
        }
    }

    public static void main(String[] args) {
        Operation op = new Operation();
        op.getName();
        op.gameSetUp();
        op.openFrame();
        while (true){
            op.runGame();            
        }
    }
}
