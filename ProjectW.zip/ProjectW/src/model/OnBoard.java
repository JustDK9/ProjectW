package model;

import model.Board;

public class OnBoard {
    public static Board board = new Board();
    
    public static Board getBoard(){
        return board;
    }
}
