package model.card.herocard;

import model.card.HeroCard;

public class IceDragon extends HeroCard {
    public IceDragon() {
        super("IceDragon", 4, "A dragon that breathes icy winds, freezing everything.", 5, 6);
    }
}