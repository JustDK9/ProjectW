package model.card;

// ***do not change***
public abstract class Card {

    private String name;
    private int price;
    private String desctiption;

    // Constructor
    public Card() {
    }

    public Card(String name, int price, String desctiption) {
        this.name = name;
        this.price = price;
        this.desctiption = desctiption;
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getDesctiption() {
        return desctiption;
    }

    public void setDesctiption(String desctiption) {
        this.desctiption = desctiption;
    }

    // Abstract methods to be implemented by subclasses

    public abstract void display();
}
