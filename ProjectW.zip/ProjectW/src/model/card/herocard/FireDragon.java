package model.card.herocard;

import model.card.HeroCard;

public class FireDragon extends HeroCard {
    public FireDragon() {
        super("FireDragon", 4, "A mighty dragon engulfed in flames.", 6, 5);
    }
}
