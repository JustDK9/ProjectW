package view.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import model.Player;
import model.card.EquipmentCard;

public class DefaultGUI extends JFrame {

    private Player ownedPlayer;
    private Player opponentPlayer;
    private model.card.Card selectedCard = null;
    private model.type.SelectedPlace selectedPlace = model.type.SelectedPlace.NONE;

    // drawing board 
    private JPanel panel_board = new JPanel();

    // drawing card on hand of owned player
    // card width = 120, height = 185
    private JPanel panel_handle = new JPanel() {
        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            int size = ownedPlayer.getHandle().getDeck().size();
            for (int i = 0; i < size; i++) {
                //button create
                JButton button_card = new JButton();
                button_card.setText(ownedPlayer.getHandle().getDeck().get(i).getName());
                button_card.setFocusable(false);
                button_card.setBounds(5 + (105 * i), 0, 100, 150);
                button_card.setLayout(null);
                //drawing card
                try {
                    Image img = new ImageIcon(getClass().getResource(ownedPlayer.getHandle().getDeck().get(i).getImage())).getImage();
                    //i dont really know why width need plus more 12px but it work!
                    Image scaledImg = img.getScaledInstance(button_card.getWidth() + 12, button_card.getHeight(), Image.SCALE_DEFAULT);
                    button_card.setIcon(new ImageIcon(scaledImg));
                } catch (NullPointerException npe) {
                    System.out.println("image not founded");
                }
                panel_handle.add(button_card);
                //button action
                button_card.addActionListener((ActionEvent ae) -> {
                    String nameSelected = button_card.getText();
                    for (var card : ownedPlayer.getHandle().getDeck()) {
                        if (card.getName().equals(nameSelected)) {
                            selectedCard = card;
                            selectedPlace = model.type.SelectedPlace.HAND;
                        }
                    }
                    System.out.println("id " + selectedCard.getId());
                    panel_info.repaint();
                    button_action.setText("EQUIP");
                    button_action.setEnabled(true);
                    System.out.println(nameSelected);
                });
            }
            for (int i = 0; i < 7 - size; i++) {
                JPanel panel = new JPanel();
                panel.setBackground(Color.lightGray);
                panel.setBounds(5 + (105 * (size + i)), 0, 100, 150);
                panel_handle.add(panel);
            }
        }
    };

    private JPanel panel_info = new JPanel() {
        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (selectedCard != null) {
                Image img = new ImageIcon(getClass().getResource(selectedCard.getImage())).getImage();
                g.drawImage(img, 5, 5, panel_info.getWidth() - 10, panel_info.getHeight() - 10, null);
            }
        }
    };

    private JPanel[] panel_offHandle = new JPanel[10];
    private JPanel[] panel_opOffHandle = new JPanel[10];
    private JPanel panel_button = new JPanel();

    public DefaultGUI(Player ownedPlayer, Player opponentPlayer) {
        this.ownedPlayer = ownedPlayer;
        this.opponentPlayer = opponentPlayer;
    }

    public void panelSetting() {
        //panel setting
        panel_board.setBounds(0, 0, 740, 470);
//        panel_board.setBackground(Color.black);
        panel_board.setLayout(null);
//        panel_handle.setBackground(Color.lightGray);
        panel_handle.setBounds(0, 470, panel_board.getWidth(), 155);
        panel_handle.setLayout(null);
        panel_info.setBackground(Color.lightGray);
        panel_info.setBounds(740, 40, 235, 355);
        panel_info.setLayout(null);
        panel_button.setBackground(Color.lightGray);
        panel_button.setBounds(740, 400, 235, 50);
        panel_button.setLayout(null);
        // board panel painting 
        for (int i = 0; i < 5; i++) {
            int curIndex = i;
            panel_offHandle[i] = new JPanel() {
                @Override
                public void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    if (ownedPlayer.getOffHandle()[curIndex] != null) {
                        Image img = new ImageIcon(getClass().getResource(ownedPlayer.getOffHandle()[curIndex].getImage())).getImage();
                        g.drawImage(img, 5, 5, panel_offHandle[curIndex].getWidth() - 10, panel_offHandle[curIndex].getHeight() - 10, null);
                    }
                }
            };
            panel_offHandle[i + 5] = new JPanel() {
                @Override
                public void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    if (ownedPlayer.getOffHandle()[curIndex] != null && ownedPlayer.getOffHandle()[curIndex].getEquipment() != null) {
                        Image img = new ImageIcon(getClass().getResource(ownedPlayer.getOffHandle()[curIndex].getEquipment().getImage())).getImage();
                        g.drawImage(img, 5, 5, panel_offHandle[curIndex].getWidth() - 10, panel_offHandle[curIndex].getHeight() - 10, null);
                    }
                }
            };
        }
        // board panel added
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 5; j++) {
//                if(i == 1) panel_offHandle[j + i * 5] = new JPanel();
                panel_offHandle[j + i * 5].setBackground(Color.lightGray);
                panel_offHandle[j + i * 5].setBounds(10 + (145 * j), 255 + (105 * i), 140, 100);
                panel_offHandle[j + i * 5].setLayout(null);
                panel_board.add(panel_offHandle[j + i * 5]);
            }
        }
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 5; j++) {
                if(i == 1) panel_opOffHandle[j + i * 5] = new JPanel();
                panel_opOffHandle[j + i * 5] = new JPanel();
                panel_opOffHandle[j + i * 5].setBackground(Color.lightGray);
                panel_opOffHandle[j + i * 5].setBounds(10 + (145 * j), 145 - (105 * i), 140, 100);
                panel_opOffHandle[j + i * 5].setLayout(null);
                panel_board.add(panel_opOffHandle[j + i * 5]);
            }
        }
        // adding panels
        this.add(panel_board);
        this.add(panel_handle);
        this.add(panel_info);
        this.add(panel_button);
    }

    private JButton[] button_offHandle_hero = new JButton[5];
    private JButton[] button_offHandle_equipment = new JButton[5];
    private JButton[] button_opOffHandle = new JButton[5];
    private JButton button_action = new JButton();
    private JButton button_end = new JButton();

    public void buttonSetting() {
        //setting buttons
        for (int i = 0; i < 5; i++) {
            button_offHandle_hero[i] = new JButton("HERO");
            button_offHandle_hero[i].setFocusable(false);
            button_offHandle_hero[i].setBounds(5, 5, panel_offHandle[i].getWidth() - 10, panel_offHandle[i].getHeight() - 10);
            button_offHandle_hero[i].setVisible(false);
            button_offHandle_equipment[i] = new JButton("EQM");
            button_offHandle_equipment[i].setFocusable(false);
            button_offHandle_equipment[i].setBounds(5, 5, panel_offHandle[i].getWidth() - 10, panel_offHandle[i].getHeight() - 10);
            button_offHandle_equipment[i].setVisible(false);
            panel_offHandle[i].add(button_offHandle_hero[i]);
            panel_offHandle[i + 5].add(button_offHandle_equipment[i]);
        }
        button_action.setText("ACTION");
        button_action.setFocusable(false);
        button_action.setBounds(5, 5, 110, 40);
        button_action.setEnabled(false);
        //add button for ally hero
        for (int i = 0; i < 5; i++) {
            int curIndex = i;
            button_offHandle_hero[i].addActionListener((ActionEvent ee) -> {
                ownedPlayer.getOffHandle()[curIndex] = (model.card.HeroCard) selectedCard;
                System.out.println("clicked at " + curIndex);
                for (var button : button_offHandle_hero) {
                    button.setVisible(false);
                }
                resetSelected();
                repaintAll();
            });
            button_offHandle_equipment[i].addActionListener((ActionEvent ei) -> {
                ownedPlayer.getOffHandle()[curIndex].setEquipment((EquipmentCard) selectedCard);
                System.out.println("clicked at " + curIndex);
                for (var button : button_offHandle_equipment) {
                    button.setVisible(false);
                }
                resetSelected();
                repaintAll();
            });
        }
        // call button out by action button
        button_action.addActionListener((ActionEvent ae) -> {
            //action of button here
            if (selectedPlace.equals(model.type.SelectedPlace.HAND)) {
                if (selectedCard instanceof model.card.HeroCard) {
                    //add listener
                    for (int i = 0; i < 5; i++) {
                        button_offHandle_hero[i].setVisible(true);
                    }
                } else if (selectedCard instanceof model.card.EquipmentCard) {
                    for (int i = 0; i < 5; i++) {
                        if (ownedPlayer.getOffHandle()[i] != null) {
                            button_offHandle_equipment[i].setVisible(true);
                        }
                    }
                }
            }
        });
        button_end.setText("END");
        button_action.setBounds(5, 5, 110, 40);
        button_end.setFocusable(false);
        button_end.setBounds(120, 5, 110, 40);
        button_end.addActionListener((ActionEvent ae) -> {
            button_end.setEnabled(false);
            for (var item : ownedPlayer.getOffHandle()) {
                System.out.println(item == null ? "null" : item.getName());
            }
        });
        //adding buttons
        panel_button.add(button_action);
        panel_button.add(button_end);
    }

    public void constructSetting() {
        //frame setting
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setSize(1000, 660);
        this.setLayout(null);
        this.setTitle(ownedPlayer.getName());
        this.setLocationRelativeTo(null);
        panelSetting();
        buttonSetting();
    }
    
    public void resetSelected(){
        selectedCard = null;
        selectedPlace = model.type.SelectedPlace.NONE;
        button_action.setEnabled(false);
        button_action.setText("ACTION");
    }
    
    public void repaintAll() {
        panel_info.repaint();
        for(var item: panel_offHandle) item.repaint();
    }

    public void run() {
        constructSetting();
        this.setVisible(true);
    }

    // testing
    public static void main(String[] args) {
        Player p1 = new Player("p1");
        p1.getHandle().addCard(new model.card.herocard.DesertNomad());
        p1.getHandle().addCard(new model.card.equipmentcard.DualBlades());
        p1.getHandle().addCard(new model.card.herocard.DesertNomad());
        p1.getHandle().addCard(new model.card.equipmentcard.DualBlades());
        p1.getHandle().addCard(new model.card.herocard.DesertNomad());
        System.out.println(p1.getHandle().getDeck().size());
        DefaultGUI gui = new DefaultGUI(p1, new Player("p2"));
        gui.run();
    }
}
