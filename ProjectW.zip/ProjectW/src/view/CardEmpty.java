/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

public class CardEmpty {
    public static String HeroCard(){
        String pinkColor = "\u001B[35m"; // Màu hồng (magenta)
        String resetColor = "\u001B[0m"; // Đặt lại màu về mặc định
        String display = pinkColor + """
                           |=================|
                           |                 |
                           |                 |
                           |                 |
                           |                 |
                           |      Hero       |
                           |                 |
                           |                 |
                           |                 |
                           |                 |
                           |=================|
                           """ + resetColor;
        return display;
    }
    
    public static String EquipmentCard(){
        String blueColor = "\u001B[34m"; // Mã màu blue
        String resetColor = "\u001B[0m"; // Đặt lại màu mặc định
        String display = blueColor + """
                           |=================|
                           |                 |
                           |                 |
                           |                 |
                           |                 |
                           |    Equipment    |
                           |                 |
                           |                 |
                           |                 |
                           |                 |
                           |=================|
                           """ + resetColor;
        return display;
    }
}
