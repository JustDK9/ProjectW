package model.card.herocard;

import model.card.HeroCard;

public class DesertNomad extends HeroCard {
    public DesertNomad() {
        super("DesertNomad", 4, "A wanderer of the endless sands.", 5, 5);
    }
}