package model.card.herocard;

import model.card.HeroCard;

public class FireWarrior extends HeroCard {
    public FireWarrior() {
        super("FireWarrior", 7, "A fierce fighter fueled by flames.", 8, 5);
    }
}