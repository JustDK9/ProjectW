package view.gui;

public class PlayerGUI extends DefaultGUI{
    
    //850, 545
    public PlayerGUI(String title, int height, int width) {
        super(title, height, width);
    }
    
}
