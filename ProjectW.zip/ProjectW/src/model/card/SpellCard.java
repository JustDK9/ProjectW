package model.card;

import model.type.SpellTarget;

public abstract class SpellCard extends Card {

    private SpellTarget spellTarget;

    public SpellCard(String name, int price, String desctiption, SpellTarget spellTarget) {
        super(name, price, desctiption);
        this.spellTarget = spellTarget;
    }

    public SpellTarget getSpellTarget() {
        return spellTarget;
    }

    public void setSpellTarget(SpellTarget spellTarget) {
        this.spellTarget = spellTarget;
    }

    public abstract void cast(HeroCard target);

    @Override
    public void display() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
