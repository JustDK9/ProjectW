/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.card.spellcard;

import java.util.Random;
import model.card.HeroCard;
import model.card.SpellCard;
import model.type.SpellTarget;

/**
 *
 * @author mew3d
 */
public class Gamblings extends SpellCard{

    public Gamblings() {
        super("Gamblings", 1, "Randomize stats for a ally hero.", SpellTarget.ACTIVE);
    }

    @Override
    public void cast(HeroCard target) {
        Random rand = new Random();
        int randAtk = rand.nextInt(7);
        int randDef = rand.nextInt(10)+1;
        target.setAttackPoint(randAtk);
        target.setDefendPoint(randDef);
    }
    
}
