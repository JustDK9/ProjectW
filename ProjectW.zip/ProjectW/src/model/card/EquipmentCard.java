package model.card;

public abstract class EquipmentCard extends Card {

    private int attackPoint;
    private int defendPoint;
    private int PassiveType;

    public EquipmentCard(String name, int price, String desctiption, int attackPoint, int defendPoint, int PassiveType) {
        super(name, price, desctiption);
        this.attackPoint = attackPoint;
        this.defendPoint = defendPoint;
        this.PassiveType = PassiveType;
    }

    public int getAttackPoint() {
        return attackPoint;
    }

    public void setAttackPoint(int attackPoint) {
        this.attackPoint = attackPoint;
    }

    public int getDefendPoint() {
        return defendPoint;
    }

    public void setDefendPoint(int defendPoint) {
        this.defendPoint = defendPoint;
    }

    public int getPassiveType() {
        return PassiveType;
    }

    public void setPassiveType(int PassiveType) {
        this.PassiveType = PassiveType;
    }

    public abstract void active(HeroCard target);

    @Override
    public void display() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
