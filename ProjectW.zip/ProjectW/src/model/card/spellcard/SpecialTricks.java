/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.card.spellcard;

import model.card.HeroCard;
import model.card.SpellCard;
import model.type.SpellTarget;

/**
 *
 * @author mew3d
 */
public class SpecialTricks extends SpellCard{

    public SpecialTricks() {
        super("SpecialTricks", 2, "Swap stats of enemy hero", SpellTarget.OPPONENT);
    }

    @Override
    public void cast(HeroCard target) {
        int temp = target.getAttackPoint();
        target.setAttackPoint(target.getAttackPoint());
        target.setDefendPoint(temp);
    }
    
}
