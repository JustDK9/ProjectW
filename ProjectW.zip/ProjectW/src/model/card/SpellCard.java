package model.card;

import model.type.SpellTarget;

public abstract class SpellCard extends Card {

    private SpellTarget option;

    public SpellCard(String name, int price, String desctiption, SpellTarget option) {
        super(name, price, desctiption);
        this.option = option;
    }

    public SpellTarget getOption() {
        return option;
    }

    public void setOption(SpellTarget option) {
        this.option = option;
    }

    public abstract void cast(HeroCard target);

    @Override
    public void display() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
