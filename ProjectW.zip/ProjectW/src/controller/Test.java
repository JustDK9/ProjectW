package controller;

import model.card.HeroCard;

public class Test {
    public static void main(String[] args) {
        HeroCard hero1 = new HeroCard("Warrior", 0, "an warrior", 3, 10);
        HeroCard hero2 = new HeroCard("Archer", 0, "an archer", 3, 10);
        hero1.attack(hero2);
        System.out.println(hero2.getDefendPoint());
    }
}
