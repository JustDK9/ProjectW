package model.card;

import java.util.ArrayList;
import java.util.Collections;

public class Deck {
    ArrayList<Card> deck = new ArrayList<>();

    public Deck() {
    }

    public ArrayList<Card> getDeck() {
        return deck;
    }

    public void setDeck(ArrayList<Card> deck) {
        this.deck = deck;
    }
    
    public void addCard(Card card){
        deck.add(card);
    }
    
    public Card selectionWithdrawCard(int index){
        Card card = deck.get(index);
        deck.remove(index);
        return card;
    }
    
    public void shuffle(){
        Collections.shuffle(deck);
    }

    public Card withdrawTopCard(){
        if(deck.isEmpty()){
            System.out.println("Deck is empty!!");
        }
        Card topCard = deck.get(0);
        deck.remove(0);
        return topCard;
    }
}
