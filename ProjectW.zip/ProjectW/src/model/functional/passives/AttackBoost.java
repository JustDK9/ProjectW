package model.functional.passives;

public class AttackBoost extends Passives{

    public AttackBoost() {
    }

    @Override
    public void action() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
