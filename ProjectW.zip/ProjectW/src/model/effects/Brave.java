package model.effects;

import model.card.HeroCard;

/**
 *
 *
 * @author Vo Hoang
 */
public class Brave extends Effects {

    public Brave() {

    }

    @Override
    public void action(HeroCard target) {
        if (target.getAttackPoint() < 10) {
            target.setAttackPoint(target.getAttackPoint() + 1);
            System.out.println(target.getName() + " increases 1 ATK!");
        } else {
            System.out.println(target.getName() + " has full ATK!");
        }
    }
}
