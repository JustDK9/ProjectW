/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.card.spellcard;

import model.card.HeroCard;
import model.card.SpellCard;
import model.effects.Healling;
import model.type.SpellTarget;

/**
 *
 * @author mew3d
 */
public class GodBlessMe extends SpellCard{

    public GodBlessMe() {
        super("God Bless Me", 3, "Bless healing effect.", SpellTarget.ACTIVE);
    }

    @Override
    public void cast(HeroCard target) {
        target.setEffect(new Healling());
        System.out.println(target.getName() + " got healling effect");
    }
    
}
