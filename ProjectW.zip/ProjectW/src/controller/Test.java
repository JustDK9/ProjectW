package controller;

import model.card.EquipmentCard;
import model.card.HeroCard;
import model.card.SpellCard;
import model.card.equipmentcard.PoisonStinger;
import model.card.spellcard.Earthquake;
import model.herocard.MountainTheif;

public class Test {
    public static void main(String[] args) {
        HeroCard hero = new MountainTheif();
        hero.display();
        SpellCard spell = new Earthquake();
        spell.display();
        EquipmentCard eqm = new PoisonStinger();
        eqm.display();
    }
}
