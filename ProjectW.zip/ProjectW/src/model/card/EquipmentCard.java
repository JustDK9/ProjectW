package model.card;

import controller.Tools;
import model.type.PassiveType;

public abstract class EquipmentCard extends Card {

    private int attackPoint;
    private int defendPoint;
    private PassiveType passiveType;

    public EquipmentCard() {
    }

    public EquipmentCard(String name, int price, String desctiption, int attackPoint, int defendPoint, PassiveType passiveType) {
        super(name, price, desctiption);
        this.attackPoint = attackPoint;
        this.defendPoint = defendPoint;
        this.passiveType = passiveType;
    }

    public int getAttackPoint() {
        return attackPoint;
    }

    public void setAttackPoint(int attackPoint) {
        this.attackPoint = attackPoint;
    }

    public int getDefendPoint() {
        return defendPoint;
    }

    public void setDefendPoint(int defendPoint) {
        this.defendPoint = defendPoint;
    }

    public PassiveType getPassiveType() {
        return passiveType;
    }

    public void setPassiveType(PassiveType passiveType) {
        this.passiveType = passiveType;
    }

    public abstract void active(HeroCard target);

    @Override
    public void display() {
        int cardWidth = 19; // Chiều rộng của thẻ
        String blueColor = "\u001B[34m"; // Mã màu blue
        String resetColor = "\u001B[0m"; // Đặt lại màu mặc định

        // Đường viền với blue
        String line = blueColor + "|=================|" + resetColor;
        System.out.println(line);

        // Tiêu đề thẻ với giá
        String stars = "*".repeat(super.getPrice()); // Tạo chuỗi dấu tương ứng với giá
        String title = " Equipment" + " ".repeat(17-9-super.getPrice()-2) + stars + " "; // Sử dụng chuỗi dấu *

        System.out.println(blueColor + "|" + Tools.centerAlign(title, cardWidth - 2) + "|" + resetColor);
        System.out.println(line);

        // Tên anh hùng
        System.out.println(blueColor + "|" + Tools.centerAlign(getName(), cardWidth - 2) + "|" + resetColor);
        System.out.println(line);
        
        // Hiển thị thống kê
        String stats = String.format("ATK:%d   DEF:%d", attackPoint, defendPoint);
        System.out.println(blueColor + "|" + Tools.centerAlign(stats, cardWidth - 2) + "|" + resetColor);
        System.out.println(line);
        
        // Hiển thị khả năng
        String ability = super.getDesctiption(); // Assuming SpellTarget is an enum, use name() to get the enum value
        String[] abilityLines = Tools.wrapText(ability, cardWidth - 2, 3); // Đặt độ rộng tối đa cho ability

        // Giới hạn số dòng hiển thị ở 3
        int maxLines = 3;
        for (int i = 0; i < Math.min(abilityLines.length, maxLines); i++) {
            // Căn giữa cho nội dung khả năng
            System.out.println(blueColor + "|" + Tools.centerAlign(abilityLines[i], cardWidth - 2) + "|" + resetColor);
        }

        // Nếu có nhiều hơn 3 dòng, thêm thông báo
        if (abilityLines.length > maxLines) {
            System.out.println(blueColor + "|" + Tools.centerAlign("...(More)", cardWidth - 2) + "|" + resetColor);
        }

        System.out.println(line); // Kết thúc thẻ
    }

}
