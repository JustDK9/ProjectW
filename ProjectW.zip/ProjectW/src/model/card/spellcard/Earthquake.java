/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.card.spellcard;

import model.OnBoard;
import model.card.HeroCard;
import model.card.SpellCard;
import model.type.SpellTarget;

/**
 *
 * @author mew3d
 */
public class Earthquake extends SpellCard{

    public Earthquake() {
        super("Earthquake", 3, "Deal damage for all heros", SpellTarget.NONE);
    }

    @Override
    public void cast(HeroCard target) {
        HeroCard[] activeHandle = OnBoard.getBoard().getActivePlayer().getOffHandle();
        HeroCard[] opponentHandle = OnBoard.getBoard().getOpponentPlayer().getOffHandle();
        for(var hero: activeHandle){
            hero.setDefendPoint(hero.getDefendPoint()-1);
        }
        for(var hero: opponentHandle){
            hero.setDefendPoint(hero.getDefendPoint()-1);
        }
        System.out.println("Earthquake have benn effect heros");
    }
    
}
