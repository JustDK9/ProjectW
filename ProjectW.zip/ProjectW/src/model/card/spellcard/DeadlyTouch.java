/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.card.spellcard;

import model.card.HeroCard;
import model.card.SpellCard;
import model.type.SpellTarget;

/**
 *
 * @author mew3d
 */
public class DeadlyTouch extends SpellCard{

    public DeadlyTouch() {
        super("Deadly Touch", 4, "Instanstly destroy an enermy hero.", SpellTarget.OPPONENT);
    }

    @Override
    public void cast(HeroCard target) {
        target.setDefendPoint(0);
        System.out.println(target.getName() + " has been fainted");
    }
    
}
