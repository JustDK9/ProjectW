package controller;

import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;
import model.OnBoard;
import model.Player;
import model.card.*;
import model.type.*;

public class DefaultGUI extends JFrame {

    private JPanel panel_master = new JPanel() {
        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            Image img_background = new ImageIcon(getClass().getResource("/view/image/CLI_Background.jpg")).getImage();
            g.drawImage(img_background, -10, -25, panel_master.getWidth(), panel_master.getHeight(), null); // drawing img_background
            if (selectedCard != null) {
                try {
                    Image img_info = new ImageIcon(getClass().getResource(selectedCard.getImage())).getImage();
                    g.drawImage(img_info, 733, 45, 235, 355, null); // drawing img_info
                } catch (NullPointerException npe) {
                    System.out.println("image not found");
                }
            }
        }
    };
    private Player player_owned;
    private Player player_opponent;
    private Card selectedCard = null;
    private SelectedPlace selectedPlace = SelectedPlace.NONE;
    
    public Player getPlayer_owned() {
        return player_owned;
    }

    public DefaultGUI(Player player_owned, Player player_opponent) {
        this.player_owned = player_owned;
        this.player_opponent = player_opponent;
    }
    
    // drawing board 
    private ArrayList<JButton> button_handle = new ArrayList<>(7);

    public void displayHandle() { // clear button_handle, panel_master<button_handle> -> create buttons & add into button_handle -> add button_handle into panel_master
        for (var item : button_handle) { // clear button_handle, panel_master<button_handle>
            item.setVisible(false);
            panel_master.remove(item);
        }
        button_handle.clear();
        int size = player_owned.getHandle().getDeck().size();
        for (int i = 0; i < size; i++) { // create buttons & add into button_handle
            // set default stats
            JButton button_card = new JButton();
            button_card.setText(player_owned.getHandle().getDeck().get(i).getName());
            button_card.setFocusable(false);
            button_card.setBounds(12 + (104 * i), 458, 96, 140);
            button_card.setLayout(null);
            // set image
            try {
                Image img = new ImageIcon(getClass().getResource(player_owned.getHandle().getDeck().get(i).getImage())).getImage();
                // ***i dont really know why width need plus more 12px but it work!
                Image scaledImg = img.getScaledInstance(button_card.getWidth() + 12, button_card.getHeight(), Image.SCALE_SMOOTH);
                button_card.setIcon(new ImageIcon(scaledImg));
            } catch (NullPointerException npe) {
                System.out.println("image not founded");
            }
            // set action
            int curIndex = i;
            button_card.addActionListener((ActionEvent) -> {
                String nameSelected = button_card.getText();
                selectedCard = player_owned.getHandle().getDeck().get(curIndex);
                selectedPlace = SelectedPlace.NONE;
                panel_master.repaint();
                if (selectedCard instanceof HeroCard || selectedCard instanceof EquipmentCard) {
                    button_action.setText("EQUIP");
                } else { // selectedCard instanceof SpellCard
                    button_action.setText("CAST");
                }
                button_action.setEnabled(true);
                System.out.println(nameSelected);
            });
            button_card.setVisible(true);
            button_handle.add(button_card);
        }
        for (var item : button_handle) { // add button_handle into panel_master 
            panel_master.add(item);
        }
    }

    private ArrayList<JButton> button_owned_board = new ArrayList<>(10);

    public void displayOwnedBoard() {
        if(selectedPlace == SelectedPlace.NONE){
            for(var item: button_owned_board){
            panel_master.remove(item);
            }
            button_owned_board.clear(); 
        }
        for (int i = 0; i < 5; i++) {
            int curIndex = i;
            // create new hero buttons on board
            JButton button_owned_hero = new JButton("empty");
            if(player_owned.getOffHandle()[curIndex] != null) {
                button_owned_hero.setText(player_owned.getOffHandle()[curIndex].getName());
            } else {
                button_owned_hero.setVisible(false);    
            }
            button_owned_hero.setBounds(32 + 139 * i, 245, 132, 97);
            button_owned_hero.setFocusable(false);
            button_owned_hero.addActionListener(((ActionEvent) -> {
                switch (selectedPlace) {
                    case NONE -> {
                        selectedCard = player_owned.getOffHandle()[curIndex];
                        button_action.setText("ATTACK");
                        button_action.setEnabled(true);
                    }
                    case SELECT -> {
                        player_owned.getOffHandle()[curIndex] = (HeroCard) selectedCard;
                        button_owned_board.get(curIndex * 2).setText(selectedCard.getName());
                        player_owned.getHandle().getDeck().remove(selectedCard);
                        for (int j = 0; j < 5; j++) { // invisibling buttons
                            if (button_owned_board.get(j * 2).getText().equals("empty")) {
                                button_owned_board.get(j * 2).setVisible(false);
                            }
                        }
                        resetSelected();

                    }
                    case S_TARGET -> {
                        // selectedCard now is spell card
                        SpellCard spellCard = (SpellCard) selectedCard;
                        spellCard.cast(player_owned.getOffHandle()[curIndex]);
                        player_owned.getHandle().getDeck().remove(selectedCard);
                    }
                }
                clearDisplayer();
                panel_master.repaint();
            }));
            panel_master.add(button_owned_hero);
            button_owned_board.add(button_owned_hero);
            // create new equipment buttons on board
            JButton button_owned_equipment = new JButton("empty");
            button_owned_equipment.setBounds(32 + 139 * i, 348, 132, 97);
            button_owned_equipment.setFocusable(false);
            button_owned_equipment.setVisible(false);
            button_owned_equipment.addActionListener((ActionEvent) -> {
                if (button_owned_board.get(curIndex * 2 + 1).getText().equals("empty")) {
                    button_owned_board.get(curIndex * 2 + 1).setText(selectedCard.getName());
                    player_owned.getOffHandle()[curIndex].setEquipment((EquipmentCard) selectedCard);
                    button_owned_board.get(curIndex * 2 + 1).setText(selectedCard.getName());
                    player_owned.getHandle().getDeck().remove(selectedCard);
                    for (int j = 0; j < 5; j++) { // invisbling buttons
                        if (button_owned_board.get(j * 2 + 1).getText().equals("empty")) {
                            button_owned_board.get(j * 2 + 1).setVisible(false);
                        }
                    }
                    resetSelected();
                    displayHandle();
                } else {
                    selectedCard = player_owned.getOffHandle()[curIndex].getEquipment();
                }
                clearDisplayer();
                panel_master.repaint();
            });
            // adding reference
            panel_master.add(button_owned_equipment);
            button_owned_board.add(button_owned_equipment);
        }
    }

    private ArrayList<JButton> button_opponent_board = new ArrayList<>(10);

    public void displayOpponentBoard() {
        for (var item: button_opponent_board){
            panel_master.remove(item);
        }
        button_opponent_board.clear();
        for (int i = 0; i < 5; i++) {
            int curIndex = i;
            // create button of opponent hero on board
            JButton button_opponent_hero = new JButton("empty");
            if (player_opponent.getOffHandle()[curIndex] != null) { // set name of hero 
                button_opponent_hero.setText(player_opponent.getOffHandle()[curIndex].getName());
                System.out.println(player_opponent.getOffHandle()[curIndex].getDefendPoint());
            } else {
                button_opponent_hero.setVisible(false);
            }
            if (player_opponent.getOffHandle()[curIndex] != null && player_opponent.getOffHandle()[curIndex].getDefendPoint() <= 0){ // delete card after fainted
                player_opponent.setHealthPoint(player_opponent.getHealthPoint() + player_opponent.getOffHandle()[curIndex].getDefendPoint());
                player_opponent.getOffHandle()[curIndex] = null;
            }
            button_opponent_hero.setBounds(32 + 139 * i, 125, 132, 97);
            button_opponent_hero.setFocusable(false);
            button_opponent_hero.addActionListener((ActionEvent) -> { // action: display info
                switch (selectedPlace) {
                    case NONE -> {
                        selectedCard = player_opponent.getOffHandle()[curIndex];
                        button_action.setText("ACTION");
                        button_action.setEnabled(false);
                    }
                    case A_TARGET -> {
                        // selectedCard now is ally hero
                        HeroCard attackCard = (HeroCard) selectedCard;
                        attackCard.attack(player_opponent.getOffHandle()[curIndex]);
                        resetSelected();
                    }
                    case S_TARGET -> { // cast error
                        // selectedCard now is spell card
                        System.out.println("here");
                        SpellCard spellCard = (SpellCard) selectedCard;
                        spellCard.cast(player_opponent.getOffHandle()[curIndex]);  
                        player_owned.getHandle().getDeck().remove(selectedCard);
                    }
                }
                clearDisplayer();
                panel_master.repaint();
            });
            panel_master.add(button_opponent_hero);
            button_opponent_board.add(button_opponent_hero);
            // create button of opponent equipment hero on board
            JButton button_opponent_equipment = new JButton("empty");
            if (player_opponent.getOffHandle()[curIndex] != null && player_opponent.getOffHandle()[curIndex].getEquipment() != null) { // set name of equipment
                button_opponent_equipment.setText(player_opponent.getOffHandle()[curIndex].getEquipment().getName());
            }
            if (button_opponent_equipment.getText().equals("empty")) { // invisibling empty button
                button_opponent_equipment.setVisible(false);
            }
            button_opponent_equipment.setBounds(32 + 139 * i, 20, 132, 97);
            button_opponent_equipment.setFocusable(false);
            button_opponent_equipment.addActionListener((ActionEvent) -> { // action: display info
                selectedCard = player_opponent.getOffHandle()[curIndex].getEquipment();
                button_action.setText("ACTION");
                button_action.setEnabled(false);
                panel_master.repaint();
            });
            panel_master.add(button_opponent_equipment);
            button_opponent_board.add(button_opponent_equipment);
        }
    }

    private JButton button_action = new JButton();
    private JButton button_end = new JButton();

    public void settingButton() {
        button_action.setText("ACTION");
        button_action.setBounds(745, 400, 110, 40);
        button_action.setFocusable(false);
        button_action.setEnabled(false);
        button_action.addActionListener((ActionEvent) -> {
            // even hero - odd equipment  
            switch (button_action.getText()) {
                case "EQUIP" -> { // visibling buttons on board
                    for (int i = 0; i < 5; i++) {
                        if (selectedCard instanceof HeroCard) {
                            button_owned_board.get(i * 2).setVisible(true);
                        }
                        if (selectedCard instanceof EquipmentCard && player_owned.getOffHandle()[i] != null) {
                            button_owned_board.get(i * 2 + 1).setVisible(true);
                        }
                    }
                    for (var button : button_owned_board) {
                        if (!button.getText().equals("empty")) {
                            button.setEnabled(false);
                        }
                    }
                    for (var button : button_opponent_board) {
                        if (!button.getText().equals("empty")) {
                            button.setEnabled(false);
                        }
                    }
                    for (var button : button_handle) {
                        button.setEnabled(false);
                    }
                    button_action.setText("CANCLE");
                    selectedPlace = SelectedPlace.SELECT;
                }
                case "CANCLE" -> { // clear & disabling buttons onboard
                    clearDisplayer();
                    panel_master.repaint();
                    resetSelected();
                    button_action.setText("ACTION");
                }
                case "CAST" -> {
                    SpellCard card = (SpellCard) selectedCard;
                    try {
                        switch (card.getSpellTarget()) {
                            case NONE -> { // cast spell to nothing
                                card.cast(new HeroCard());
                            }
                            case ACTIVE -> { // cast spell to allies
                                for (int i = 0; i < 5; i++) {
                                    button_owned_board.get(i * 2 + 1).setEnabled(false);
                                }
                                for (var button : button_opponent_board) {
                                    button.setEnabled(false);
                                }
                                for (var button : button_handle) {
                                    button.setEnabled(false);
                                }
                                selectedPlace = SelectedPlace.S_TARGET;
                                button_action.setText("CANCLE");
                            }
                            case OPPONENT -> { // cast spell to enemies
                                for (int i = 0; i < 5; i++) {
                                    button_opponent_board.get(i * 2 + 1).setEnabled(false);
                                }
                                for (var button : button_owned_board) {
                                    button.setEnabled(false);
                                }
                                for (var button : button_handle) {
                                    button.setEnabled(false);
                                }
                                selectedPlace = SelectedPlace.S_TARGET;
                                button_action.setText("CANCLE");
                            }
                        }
                    } catch (Exception e) {
                        System.out.println("cast fault");
                    }
                }
                case "ATTACK" -> {
                    for (int i = 0; i < 5; i++) {
                        button_opponent_board.get(i * 2 + 1).setEnabled(false);
                    }
                    for (var button : button_owned_board) {
                        button.setEnabled(false);
                    }
                    for (var button : button_handle) {
                        button.setEnabled(false);
                    }
                    selectedPlace = SelectedPlace.A_TARGET;
                    button_action.setText("CANCLE");
                }
            }
        });
        panel_master.add(button_action);
        // button end
        button_end.setText("End");
        button_end.setBounds(863, 400, 110, 40);
        button_end.setFocusable(false);
        button_end.addActionListener((ActionListener) -> {
            resetSelected();
            player_owned.setQueue(TurnQueue.OPPONENT);
            player_opponent.setQueue(TurnQueue.ACTIVE);
            System.out.println("End Turn");
        });
        panel_master.add(button_end);
    }

    public void constructSetting() {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setSize(1000, 660);
        this.setLayout(null);
        this.setTitle(player_owned.getName());
        this.setLocationRelativeTo(null);
        displayOwnedBoard();
        displayOpponentBoard();
        displayHandle();
        settingButton();
        panel_master.setBounds(0, 0, this.getWidth(), this.getHeight());
        panel_master.setLayout(null);
        this.add(panel_master);
    }

    public void clearDisplayer() { // invisibling buttons on board
        for (int j = 0; j < 5; j++) {
            if (button_owned_board.get(j * 2).getText().equals("empty")) {
                button_owned_board.get(j * 2).setVisible(false);
            }
            if (button_owned_board.get(j * 2 + 1).getText().equals("empty")) {
                button_owned_board.get(j * 2 + 1).setVisible(false);
            }
        }
        for (var button : button_owned_board) {
            button.setEnabled(true);
        }
        for (var button : button_opponent_board) {
            button.setEnabled(true);
        }
        for (var button : button_handle) {
            button.setEnabled(true);
        }
        displayHandle();
    }
    
    public void updating(){
        goTurn();
        displayOpponentBoard();
        displayOwnedBoard();
        panel_master.repaint();
//        System.out.println(player_owned.getName() + "updating");
    }
    
    public void resetSelected() { // reset info & selection
        selectedCard = null;
        selectedPlace = SelectedPlace.NONE;
        button_action.setEnabled(false);
        button_action.setText("ACTION");
    }
    
    public void goTurn(){
        switch (player_owned.getQueue()){
            case ACTIVE -> {
                System.out.println("active");
                button_action.setVisible(true);
                button_end.setVisible(true);
                player_owned.getHandle().addCard(OnBoard.getBoard().getMainDeck().withdrawTopCard());
                displayHandle();
                panel_master.repaint();
                player_owned.setQueue(TurnQueue.WAIT);
            }
            case OPPONENT -> {
                button_action.setVisible(false);
                button_end.setVisible(false);
                System.out.println("oppo");
                player_owned.setQueue(TurnQueue.WAIT);
            }
        }
    }
    
    public void run() {
        constructSetting();
        this.setVisible(true);
    }
}
