package model.card;

// ***do not change***
public class Card {
    
    public static int masterId = 0; 
    private final int id = ++masterId;
    private String name;
    private int price;
    private String desctiption;

    // Constructor
    public Card() {
    }

    public Card(String name, int price, String desctiption) {
        this.name = name;
        this.price = price;
        this.desctiption = desctiption;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }
//
//    public void setId(int id) {
//        this.id = id;
//    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getDesctiption() {
        return desctiption;
    }

    public void setDesctiption(String desctiption) {
        this.desctiption = desctiption;
    }

    public String getImage() {
        return "/view/image/" + name + ".jpg";
    }
}
