package controller;

import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;
import model.OnBoard;
import model.Player;
import model.card.*;
import model.type.*;

public class DefaultGUI extends JFrame {

    private JPanel panel_master = new JPanel() {
        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            Image img_background = new ImageIcon(getClass().getResource("/view/image/CLI_Background.jpg")).getImage();
            g.drawImage(img_background, -10, -25, panel_master.getWidth(), panel_master.getHeight(), null); // drawing img_background
            if (selectedCard != null) {
                try {
                    Image img_info = new ImageIcon(getClass().getResource(selectedCard.getImage())).getImage();
                    g.drawImage(img_info, 736, 35, 235, 352, null); // drawing img_info
                } catch (NullPointerException npe) {
                    System.out.println("image not found");
                }
            }
            // drawing text/string
            g.setFont(new Font("Arial", Font.BOLD, 20));
            if (selectedCard != null && selectedCard instanceof HeroCard || selectedCard instanceof EquipmentCard) {
                if (selectedCard instanceof HeroCard card) {
                    g.setColor(new Color(255, 140, 90));
                    g.drawString("" + card.getAttackPoint(), 810, 264);
                    g.drawString("" + card.getDefendPoint(), 913, 264);
                } else {
                    EquipmentCard card = (EquipmentCard) selectedCard;
                    g.setColor(new Color(110, 110, 255));
                    g.drawString("ATK: " + card.getAttackPoint(), 765, 264);
                    g.drawString("DEF: " + card.getDefendPoint(), 875, 264);
                }
            }
            g.setFont(new Font("Arial", Font.BOLD, 20));
            g.setColor(Color.green);
            g.drawString(player_owned.getName() + " HP: " + player_owned.getHealthPoint() + " | MP: " + player_owned.getManaPoint(), 700, 22); // player_owned hp
            g.setColor(Color.red);
            g.drawString(player_opponent.getName() + " HP: " + player_opponent.getHealthPoint(), 30, 22); // player_opponent hp
        }
    };
    private Player player_owned;
    private Player player_opponent;
    private Card selectedCard = null;
    private SelectedPlace selectedPlace = SelectedPlace.NONE;

    public Player getPlayer_owned() {
        return player_owned;
    }

    public DefaultGUI(Player player_owned, Player player_opponent) {
        this.player_owned = player_owned;
        this.player_opponent = player_opponent;
    }

    // drawing board 
    private ArrayList<JButton> button_handle = new ArrayList<>(7);

    public void displayHandle() { // clear button_handle, panel_master<button_handle> -> create buttons & add into button_handle -> add button_handle into panel_master
        for (var item : button_handle) { // clear button_handle, panel_master<button_handle>
            item.setVisible(false);
            panel_master.remove(item);
        }
        button_handle.clear();
        int size = player_owned.getHandle().getDeck().size();
        for (int i = 0; i < size; i++) { // create buttons & add into button_handle
            // set default stats
            JButton button_card = new JButton();
//            button_card.setText(player_owned.getHandle().getDeck().get(i).getName());
            button_card.setFocusable(false);
            button_card.setBounds(8 + (103 * i), 472, 96, 140);
            button_card.setBorder(BorderFactory.createEmptyBorder());
            button_card.setHorizontalTextPosition(SwingConstants.CENTER);
            button_card.setVerticalTextPosition(SwingConstants.CENTER);
            // set image
            try {
                Image img = new ImageIcon(getClass().getResource(player_owned.getHandle().getDeck().get(i).getImage())).getImage();
                // ***i dont really know why width need plus more 12px but it work!
                Image scaledImg = img.getScaledInstance(button_card.getWidth(), button_card.getHeight(), Image.SCALE_SMOOTH);
                button_card.setIcon(new ImageIcon(scaledImg));
            } catch (NullPointerException npe) {
                System.out.println("image not founded");
            }
            // set action
            int curIndex = i;
            button_card.addActionListener((ActionEvent) -> {
                String nameSelected = button_card.getText();
                selectedCard = player_owned.getHandle().getDeck().get(curIndex);
                System.out.println(player_owned.getName() + " - Handle card cliked [" + curIndex + "] - " + selectedCard.getName());
                switch (selectedPlace) {
                    case NONE -> {
                        if (selectedCard instanceof HeroCard || selectedCard instanceof EquipmentCard) {
                            button_action.setText("EQUIP");
                        } else { // selectedCard instanceof SpellCard
                            button_action.setText("CAST");
                        }
                        if (selectedCard.getPrice() <= player_owned.getManaPoint()) {
                            button_action.setEnabled(true);
                        } else {
                            button_action.setEnabled(false);
                        }
                        System.out.println(nameSelected);
                    }
                    case REMOVE -> {
                        button_action.setText("DISCARD");
                        button_action.setEnabled(true);
                    }
                }
                panel_master.repaint();
            });
            button_card.setVisible(true);
            button_handle.add(button_card);
        }
        for (var item : button_handle) { // add button_handle into panel_master 
            panel_master.add(item);
        }
    }

    private ArrayList<JButton> button_owned_board = new ArrayList<>(10);

    public void displayOwnedBoard() {
        if (selectedPlace == SelectedPlace.NONE) {
            for (var item : button_owned_board) {
                panel_master.remove(item);
            }
            button_owned_board.clear();
        }
        for (int i = 0; i < 5; i++) {
            int curIndex = i;
            // create new hero buttons on board
            JButton button_owned_hero = new JButton("empty");
            button_owned_hero.setBorder(BorderFactory.createEmptyBorder());
            button_owned_hero.setHorizontalTextPosition(SwingConstants.CENTER);
            button_owned_hero.setVerticalTextPosition(SwingConstants.CENTER);
            if (player_owned.getOffHandle()[curIndex] != null) {
//                button_owned_hero.setText(player_owned.getOffHandle()[curIndex].getName());
                button_owned_hero.setText("");
                button_owned_hero.setBounds(42 + 145 * i, 257, 70, 95);
                try {
                    Image img = new ImageIcon(getClass().getResource(player_owned.getOffHandle()[curIndex].getImage())).getImage();
                    Image scaledImg = img.getScaledInstance(button_owned_hero.getWidth(), button_owned_hero.getHeight(), Image.SCALE_SMOOTH);
                    button_owned_hero.setIcon(new ImageIcon(scaledImg));
                } catch (NullPointerException npe) {
                    System.out.println("image not founded");
                }
            } else {
                button_owned_hero.setVisible(false);
                button_owned_hero.setBounds(9 + 145 * i, 257, 132, 95);
            }
            button_owned_hero.setFocusable(false);
            button_owned_hero.addActionListener(((ActionEvent) -> {
                switch (selectedPlace) {
                    case NONE -> {
                        selectedCard = player_owned.getOffHandle()[curIndex];
                        button_action.setText("ATTACK");
                        if (((HeroCard) selectedCard).isAttCheck() || Operation.turn < 2) {
                            button_action.setEnabled(false);
                        } else {
                            button_action.setEnabled(true);
                        }
                    }
                    case SELECT -> {
                        player_owned.getOffHandle()[curIndex] = (HeroCard) selectedCard;
                        button_owned_board.get(curIndex * 2).setText(selectedCard.getName());
                        player_owned.getHandle().getDeck().remove(selectedCard);
                        for (int j = 0; j < 5; j++) { // invisibling buttons
                            if (button_owned_board.get(j * 2).getText().equals("empty")) {
                                button_owned_board.get(j * 2).setVisible(false);
                            }
                        }
                        resetSelected();
                    }
                    case S_TARGET -> {
                        // selectedCard now is spell card
                        SpellCard spellCard = (SpellCard) selectedCard;
                        spellCard.cast(player_owned.getOffHandle()[curIndex]);
                        player_owned.getHandle().getDeck().remove(selectedCard);
                        resetSelected();
                    }
                }
                clearDisplayer();
                panel_master.repaint();
                Operation.updateSignal = true;
            }));
            panel_master.add(button_owned_hero);
            button_owned_board.add(button_owned_hero);
            // create new equipment buttons on board
            JButton button_owned_equipment = new JButton("empty");
            button_owned_equipment.setBorder(BorderFactory.createEmptyBorder());
            button_owned_equipment.setHorizontalTextPosition(SwingConstants.CENTER);
            button_owned_equipment.setVerticalTextPosition(SwingConstants.CENTER);
            if (player_owned.getOffHandle()[curIndex] != null && player_owned.getOffHandle()[curIndex].getEquipment() != null) {
//                button_owned_equipment.setText(player_owned.getOffHandle()[curIndex].getEquipment().getName());
                button_owned_equipment.setText("");
                button_owned_equipment.setBounds(42 + 145 * i, 361, 70, 95);
                try {
                    Image img = new ImageIcon(getClass().getResource(player_owned.getOffHandle()[curIndex].getEquipment().getImage())).getImage();
                    Image scaledImg = img.getScaledInstance(button_owned_equipment.getWidth(), button_owned_equipment.getHeight(), Image.SCALE_SMOOTH);
                    button_owned_equipment.setIcon(new ImageIcon(scaledImg));
                } catch (NullPointerException npe) {
                    System.out.println("image not founded");
                }
            } else {
                button_owned_equipment.setVisible(false);
                button_owned_equipment.setBounds(9 + 145 * i, 361, 132, 95);
            }
            button_owned_equipment.setFocusable(false);
            button_owned_equipment.addActionListener((ActionEvent) -> {
                if (button_owned_board.get(curIndex * 2 + 1).getText().equals("empty")) {
                    button_owned_board.get(curIndex * 2 + 1).setText(selectedCard.getName());
                    player_owned.getOffHandle()[curIndex].setEquipment((EquipmentCard) selectedCard);
                    button_owned_board.get(curIndex * 2 + 1).setText(selectedCard.getName());
                    player_owned.getHandle().getDeck().remove(selectedCard);
                    for (int j = 0; j < 5; j++) { // invisbling buttons
                        if (button_owned_board.get(j * 2 + 1).getText().equals("empty")) {
                            button_owned_board.get(j * 2 + 1).setVisible(false);
                        }
                    }
                    resetSelected();
                    displayHandle();
                } else {
                    selectedCard = player_owned.getOffHandle()[curIndex].getEquipment();
                }
                clearDisplayer();
                panel_master.repaint();
                Operation.updateSignal = true;
            });
            // adding reference
            panel_master.add(button_owned_equipment);
            button_owned_board.add(button_owned_equipment);
        }
    }

    private ArrayList<JButton> button_opponent_board = new ArrayList<>(10);

    public void displayOpponentBoard() {
        if (selectedPlace == SelectedPlace.NONE) {
            for (var item : button_opponent_board) {
                panel_master.remove(item);
            }
            button_opponent_board.clear();
        }
        for (int i = 0; i < 5; i++) {
            int curIndex = i;
            // create button of opponent hero on board
            JButton button_opponent_hero = new JButton("empty");
            button_opponent_hero.setBorder(BorderFactory.createEmptyBorder());
            button_opponent_hero.setHorizontalTextPosition(SwingConstants.CENTER);
            button_opponent_hero.setVerticalTextPosition(SwingConstants.CENTER);
            if (player_opponent.getOffHandle()[curIndex] != null) { // set name of hero 
//                button_opponent_hero.setText(player_opponent.getOffHandle()[curIndex].getName());
                button_opponent_hero.setText("");
                button_opponent_hero.setBounds(42 + 145 * i, 137, 70, 95);
                try {
                    Image img = new ImageIcon(getClass().getResource(player_opponent.getOffHandle()[curIndex].getImage())).getImage();
                    Image scaledImg = img.getScaledInstance(button_opponent_hero.getWidth(), button_opponent_hero.getHeight(), Image.SCALE_SMOOTH);
                    button_opponent_hero.setIcon(new ImageIcon(scaledImg));
                } catch (NullPointerException npe) {
                    System.out.println("image not founded");
                }
            } else {
                button_opponent_hero.setBounds(9 + 145 * i, 137, 132, 95);
                button_opponent_hero.setVisible(false);
            }
            if (player_opponent.getOffHandle()[curIndex] != null && player_opponent.getOffHandle()[curIndex].getDefendPoint() <= 0) { // delete card after fainted
                player_opponent.setHealthPoint(player_opponent.getHealthPoint() + player_opponent.getOffHandle()[curIndex].getDefendPoint());
                player_opponent.getOffHandle()[curIndex] = null;
            }
            button_opponent_hero.setFocusable(false);
            button_opponent_hero.addActionListener((ActionEvent) -> { // action: display info
                switch (selectedPlace) {
                    case NONE -> {
                        selectedCard = player_opponent.getOffHandle()[curIndex];
                        button_action.setText("ACTION");
                        button_action.setEnabled(false);
                    }
                    case A_TARGET -> {
                        // selectedCard now is ally hero
                        HeroCard attackCard = (HeroCard) selectedCard;
                        attackCard.attack(player_opponent.getOffHandle()[curIndex]);
                        resetSelected();
                    }
                    case S_TARGET -> { // cast error
                        // selectedCard now is spell card
                        SpellCard spellCard = (SpellCard) selectedCard;
                        spellCard.cast(player_opponent.getOffHandle()[curIndex]);
                        player_owned.getHandle().getDeck().remove(selectedCard);
                        resetSelected();
                    }
                }
                clearDisplayer();
                panel_master.repaint();
                Operation.updateSignal = true;
            });
            panel_master.add(button_opponent_hero);
            button_opponent_board.add(button_opponent_hero);
            // create button of opponent equipment hero on board
            JButton button_opponent_equipment = new JButton("empty");
            button_opponent_equipment.setBorder(BorderFactory.createEmptyBorder());
            button_opponent_equipment.setHorizontalTextPosition(SwingConstants.CENTER);
            button_opponent_equipment.setVerticalTextPosition(SwingConstants.CENTER);
            if (player_opponent.getOffHandle()[curIndex] != null && player_opponent.getOffHandle()[curIndex].getEquipment() != null) { // set name of equipment
//                button_opponent_equipment.setText(player_opponent.getOffHandle()[curIndex].getEquipment().getName());
                button_opponent_equipment.setText("");
                button_opponent_equipment.setBounds(42 + 145 * i, 33, 70, 95);
                try {
                    Image img = new ImageIcon(getClass().getResource(player_opponent.getOffHandle()[curIndex].getEquipment().getImage())).getImage();
                    Image scaledImg = img.getScaledInstance(button_opponent_equipment.getWidth(), button_opponent_equipment.getHeight(), Image.SCALE_SMOOTH);
                    button_opponent_equipment.setIcon(new ImageIcon(scaledImg));
                } catch (NullPointerException npe) {
                    System.out.println("image not founded");
                }
            }
            if (button_opponent_equipment.getText().equals("empty")) { // invisibling empty button
                button_opponent_equipment.setVisible(false);
                button_opponent_equipment.setBounds(9 + 145 * i, 55, 132, 95);
            }
            button_opponent_equipment.setFocusable(false);
            button_opponent_equipment.addActionListener((ActionEvent) -> { // action: display info
                selectedCard = player_opponent.getOffHandle()[curIndex].getEquipment();
                button_action.setText("ACTION");
                button_action.setEnabled(false);
                panel_master.repaint();
                Operation.updateSignal = true;
            });
            panel_master.add(button_opponent_equipment);
            button_opponent_board.add(button_opponent_equipment);
        }
    }

    private JButton button_action = new JButton();
    private JButton button_end = new JButton();

    public void settingButton() {
        button_action.setText("ACTION");
        button_action.setBounds(745, 400, 110, 40);
        button_action.setFocusable(false);
        button_action.setEnabled(false);
        button_action.addActionListener((ActionEvent) -> {
            // even hero - odd equipment  
            switch (button_action.getText()) {
                case "EQUIP" -> { // visibling buttons on board
                    for (int i = 0; i < 5; i++) {
                        if (selectedCard instanceof HeroCard) {
                            button_owned_board.get(i * 2).setVisible(true);
                        }
                        if (selectedCard instanceof EquipmentCard && player_owned.getOffHandle()[i] != null) {
                            button_owned_board.get(i * 2 + 1).setVisible(true);
                        }
                    }
                    for (var button : button_owned_board) {
                        if (!button.getText().equals("empty")) {
                            button.setEnabled(false);
                        }
                    }
                    for (var button : button_opponent_board) {
                        if (!button.getText().equals("empty")) {
                            button.setEnabled(false);
                        }
                    }
                    for (var button : button_handle) {
                        button.setEnabled(false);
                    }
                    button_action.setText("CANCLE");
                    selectedPlace = SelectedPlace.SELECT;
                    player_owned.setManaPoint(player_owned.getManaPoint() - selectedCard.getPrice());
                    System.out.println(player_owned.getName() + " - Button clicked <Equip>!");
                }
                case "CANCLE" -> { // clear & disabling buttons onboard
                    clearDisplayer();
                    player_owned.setManaPoint(player_owned.getManaPoint() + selectedCard.getPrice());
                    panel_master.repaint();
                    resetSelected();
                    button_action.setText("ACTION");
                    System.out.println(player_owned.getName() + " - Button clicked <Cancle>!");
                }
                case "CAST" -> {
                    SpellCard card = (SpellCard) selectedCard;
                    try {
                        switch (card.getSpellTarget()) {
                            case NONE -> { // cast spell to nothing
                                card.cast(new HeroCard());
                                player_owned.getHandle().getDeck().remove(selectedCard);
                                resetSelected();
                                clearDisplayer();
                            }
                            case ACTIVE -> { // cast spell to allies
                                for (int i = 0; i < 5; i++) {
                                    button_owned_board.get(i * 2 + 1).setEnabled(false);
                                }
                                for (var button : button_opponent_board) {
                                    button.setEnabled(false);
                                }
                                for (var button : button_handle) {
                                    button.setEnabled(false);
                                }
                                player_owned.setManaPoint(player_owned.getManaPoint() - selectedCard.getPrice());
                                selectedPlace = SelectedPlace.S_TARGET;
                                button_action.setText("CANCLE");
                            }
                            case OPPONENT -> { // cast spell to enemies
                                for (int i = 0; i < 5; i++) {
                                    button_opponent_board.get(i * 2 + 1).setEnabled(false);
                                }
                                for (var button : button_owned_board) {
                                    button.setEnabled(false);
                                }
                                for (var button : button_handle) {
                                    button.setEnabled(false);
                                }
                                player_owned.setManaPoint(player_owned.getManaPoint() - selectedCard.getPrice());
                                selectedPlace = SelectedPlace.S_TARGET;
                                button_action.setText("CANCLE");
                            }
                        }
                        panel_master.repaint();
                        Operation.updateSignal = true;
                        System.out.println(player_owned.getName() + " - Button clicked <Cast>!");
                    } catch (Exception e) {
                        System.out.println("cast fault");
                    }
                }
                case "ATTACK" -> {
                    int enemyCount = 0;
                    for (var item : player_opponent.getOffHandle()) {
                        if (item != null) {
                            enemyCount++;
                        }
                    }
                    if (enemyCount == 0) {
                        player_owned.setHealthPoint(player_owned.getHealthPoint() - ((HeroCard) selectedCard).getAttackPoint());
                        ((HeroCard) selectedCard).setAttCheck(true);
                        resetSelected();
                    } else {
                        for (int i = 0; i < 5; i++) {
                            button_opponent_board.get(i * 2 + 1).setEnabled(false);
                        }
                        for (var button : button_owned_board) {
                            button.setEnabled(false);
                        }
                        for (var button : button_handle) {
                            button.setEnabled(false);
                        }
                        selectedPlace = SelectedPlace.A_TARGET;
                        button_action.setText("CANCLE");
                        System.out.println(player_owned.getName() + " - Button clicked <Attack>!");
                    }
                }
                case "DISCARD" -> {
                    player_owned.getHandle().getDeck().remove(selectedCard);
                    displayHandle();
                    System.out.println(player_owned.getName() + " - Button clicked <Discard>!");
                }
            }
            Operation.updateSignal = true;
        });
        panel_master.add(button_action);
        // button end
        button_end.setText("End");
        button_end.setBounds(863, 400, 110, 40);
        button_end.setFocusable(false);
        button_end.addActionListener((ActionListener) -> {
            if (player_owned.getHandle().getDeck().size() > 7) {
                selectedPlace = SelectedPlace.REMOVE;
            } else {
                selectedPlace = SelectedPlace.NONE;
            }
            switch (selectedPlace) {
                case REMOVE -> {
                    button_action.setText("DISCARD");
                    for (var item : button_owned_board) {
                        item.setEnabled(false);
                    }
                    for (var item : button_opponent_board) {
                        item.setEnabled(false);
                    }
                }
                case NONE -> {
                    resetSelected();
                    System.out.println(player_owned.getName() + " - Button Cliked <End>!");
                    player_owned.setQueue(TurnQueue.OPPONENT);
                    player_opponent.setQueue(TurnQueue.ACTIVE);
                    Operation.turn++;
                    Operation.updateSignal = true;
                }
            }
        });
        panel_master.add(button_end);
    }

    public void constructSetting() {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setSize(1000, 660);
        this.setLayout(null);
        this.setTitle(player_owned.getName());
        this.setLocationRelativeTo(null);
        displayOwnedBoard();
        displayOpponentBoard();
        displayHandle();
        settingButton();
        panel_master.setBounds(0, 0, this.getWidth(), this.getHeight());
        panel_master.setLayout(null);
        this.add(panel_master);
    }

    public void clearDisplayer() { // invisibling buttons on board
        for (int j = 0; j < 5; j++) {
            if (button_owned_board.get(j * 2).getText().equals("empty")) {
                button_owned_board.get(j * 2).setVisible(false);
            }
            if (button_owned_board.get(j * 2 + 1).getText().equals("empty")) {
                button_owned_board.get(j * 2 + 1).setVisible(false);
            }
        }
        for (var button : button_owned_board) {
            button.setEnabled(true);
        }
        for (var button : button_opponent_board) {
            button.setEnabled(true);
        }
        for (var button : button_handle) {
            button.setEnabled(true);
        }
        displayHandle();
    }

    public void updating() {
        goTurn();
        displayOpponentBoard();
        displayOwnedBoard();
        panel_master.repaint();
        System.out.println(player_owned.getName() + " - *Update UI*");
    }

    public void resetSelected() { // reset info & selection
        selectedCard = null;
        selectedPlace = SelectedPlace.NONE;
        button_action.setEnabled(false);
        button_action.setText("ACTION");
        updating();
    }

    public void goTurn() {
        switch (player_owned.getQueue()) {
            case ACTIVE -> { // start the turn
                button_action.setVisible(true);
                button_end.setVisible(true);
                player_owned.setManaPoint(20);
                player_owned.getHandle().addCard(OnBoard.getBoard().getMainDeck().withdrawTopCard());
                displayHandle();
                panel_master.repaint();
                OnBoard.getBoard().setActivePlayer(player_owned);
                for (var item : player_owned.getOffHandle()) {
                    if (item != null) {
                        item.setAttCheck(false);
                    }
                    if (item != null && item.getEffect() != null) {
                        item.getEffect().action(item);
                    }
                }
                player_owned.setQueue(TurnQueue.WAIT);
                System.out.println(player_owned.getName() + " turn!");
            }
            case OPPONENT -> {
                button_action.setVisible(false);
                button_end.setVisible(false);
                OnBoard.getBoard().setOpponentPlayer(player_owned);
                player_owned.setQueue(TurnQueue.WAIT);
            }
        }
    }

    public void run() {
        constructSetting();
        this.setVisible(true);
    }
}
