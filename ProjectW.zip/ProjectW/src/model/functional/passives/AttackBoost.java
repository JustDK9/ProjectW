package model.functional.passives;

import model.card.HeroCard;

public class AttackBoost extends Passives{

    public AttackBoost() {
    }

    @Override
    public void action(HeroCard target) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
