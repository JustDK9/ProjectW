package model.card;

import model.OnBoard;
import model.effects.Effects;
import model.type.PassiveType;

public class HeroCard extends Card {

    private int attackPoint;
    private int defendPoint;
    private EquipmentCard equipment;
    private Effects effect;

    public HeroCard() {
    }

    public HeroCard(String name, int price, String desctiption, int attackPoint, int defendPoint) {
        super(name, price, desctiption);
        this.attackPoint = attackPoint;
        this.defendPoint = defendPoint;
    }

    public int getAttackPoint() {
        return attackPoint;
    }

    public void setAttackPoint(int attackPoint) {
        this.attackPoint = attackPoint;
    }

    public int getDefendPoint() {
        return defendPoint;
    }

    public void setDefendPoint(int defendPoint) {
        this.defendPoint = defendPoint;
    }

    public EquipmentCard getEquipment() {
        return equipment;
    }

    public void setEquipment(EquipmentCard equipment) {
        this.equipment = equipment;
    }

    public Effects getEffect() {
        return effect;
    }

    public void setEffect(Effects effect) {
        this.effect = effect;
    }

    public void attack(HeroCard target) {
        if (equipment != null && equipment.getPassiveType() == PassiveType.ATTACK) {
        }
        if (target.getEquipment() != null && target.getEquipment().getPassiveType() == PassiveType.DEFEND) {
        }
        int damage = attackPoint;
        if (equipment != null) {
            damage += equipment.getAttackPoint();
        }
        target.setDefendPoint(target.getDefendPoint() - damage);
        if (target.getDefendPoint() < 0) {
            OnBoard.getBoard().getOpponentPlayer().setHealthPoint(OnBoard.getBoard().getOpponentPlayer().getHealthPoint() - target.getDefendPoint());
        }
        System.out.println("Attack successfully");
    }
}
