/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.card.equipmentcard;

import model.card.EquipmentCard;
import model.card.HeroCard;
import model.effects.Healling;
import model.type.PassiveType;

/**
 *
 * @author mew3d
 */
public class NaturalStaff extends EquipmentCard{

    public NaturalStaff() {
        super("NaturalStaff", 4, "Get healling effect when get hit.", 3, 1, PassiveType.DEFEND);
    }

    @Override
    public void active(HeroCard active, HeroCard opponent) {
        active.setEffect(new Healling());
        System.out.println("");
    }
    
}
