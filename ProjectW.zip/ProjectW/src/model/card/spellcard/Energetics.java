/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.card.spellcard;

import model.OnBoard;
import model.card.HeroCard;
import model.card.SpellCard;
import model.type.SpellTarget;

/**
 *
 * @author mew3d
 */
public class Energetics extends SpellCard{

    public Energetics() {
        super("Energetics", 1, "Restore 3 mana point.", SpellTarget.NONE);
    }

    @Override
    public void cast(HeroCard target) {
        OnBoard.getBoard().getActivePlayer().setManaPoint(OnBoard.getBoard().getActivePlayer().getManaPoint() + 4);
        System.out.println(OnBoard.getBoard().getActivePlayer().getName() + " have been restore 3 mana point.");
    }
    
}
