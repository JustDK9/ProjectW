package model.card;

import controller.Tools;
import model.OnBoard;
import model.effects.Effects;
import model.type.PassiveType;

public class HeroCard extends Card {

    private int attackPoint;
    private int defendPoint;
    private EquipmentCard equipment;
    private Effects effect;

    public HeroCard() {
    }

    public HeroCard(String name, int price, String desctiption, int attackPoint, int defendPoint) {
        super(name, price, desctiption);
        this.attackPoint = attackPoint;
        this.defendPoint = defendPoint;
    }

    public int getAttackPoint() {
        return attackPoint;
    }

    public void setAttackPoint(int attackPoint) {
        this.attackPoint = attackPoint;
    }

    public int getDefendPoint() {
        return defendPoint;
    }

    public void setDefendPoint(int defendPoint) {
        this.defendPoint = defendPoint;
    }

    public EquipmentCard getEquipment() {
        return equipment;
    }

    public void setEquipment(EquipmentCard equipment) {
        this.equipment = equipment;
    }

    public Effects getEffect() {
        return effect;
    }

    public void setEffect(Effects effect) {
        this.effect = effect;
    }

    public void attack(HeroCard target) {
        if (equipment != null && equipment.getPassiveType() == PassiveType.ATTACK) {
        }
        if (target.getEquipment() != null && target.getEquipment().getPassiveType() == PassiveType.DEFEND) {
        }
        int damage = attackPoint;
        if (equipment != null) {
            damage += equipment.getAttackPoint();
        }
        target.setDefendPoint(target.getDefendPoint() - damage);
        if (target.getDefendPoint() < 0) {
            OnBoard.getBoard().getOpponentPlayer().setHealthPoint(OnBoard.getBoard().getOpponentPlayer().getHealthPoint() - target.getDefendPoint());
        }
        System.out.println("Attack successfully");
    }

    @Override
    public void display() {
        int cardWidth = 19; // Chiều rộng của thẻ
        String pinkColor = "\u001B[35m"; // Màu hồng (magenta)
        String resetColor = "\u001B[0m"; // Đặt lại màu về mặc định

        String line = pinkColor + "|=================|" + resetColor; // Tạo đường viền với màu hồng
        System.out.println(line);

        // Tiêu đề thẻ với giá
        String stars = "*".repeat(super.getPrice()); // Tạo chuỗi dấu tương ứng với giá
        String title = " Hero" + " ".repeat(17-4-super.getPrice()-2) + stars + " "; // Sử dụng chuỗi dấu *

        System.out.println(pinkColor + "|" + title + "|" + resetColor);
        System.out.println(line);

        // Tên anh hùng
        System.out.println(pinkColor + "|" + Tools.centerAlign(getName(), cardWidth - 2) + "|" + resetColor);
        System.out.println(line);

        // Hiển thị thống kê
        String stats = String.format("ATK:%d   DEF:%d", attackPoint, defendPoint);
        System.out.println(pinkColor + "|" + Tools.centerAlign(stats, cardWidth - 2) + "|" + resetColor);
        System.out.println(line);

        // Hiển thị khả năng
        String ability = super.getDesctiption(); // Check for null effect
        String[] abilityLines = Tools.wrapText(ability, cardWidth - 2, 3); // Đặt độ rộng tối đa cho ability

        // Giới hạn số dòng hiển thị ở 3
        int maxLines = 3;
        for (int i = 0; i < Math.min(abilityLines.length, maxLines); i++) {
            // Căn giữa cho nội dung khả năng
            System.out.println(pinkColor + "|" + Tools.centerAlign(abilityLines[i], cardWidth - 2) + "|" + resetColor);
        }

        // Nếu có nhiều hơn 3 dòng, thêm thông báo
        if (abilityLines.length > maxLines) {
            System.out.println(pinkColor + "|" + Tools.centerAlign("...(More)", cardWidth - 2) + "|" + resetColor);
        }

        System.out.println(line); // Kết thúc thẻ
    }

}
