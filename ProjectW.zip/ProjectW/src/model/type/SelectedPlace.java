package model.type;

public enum SelectedPlace {
    A_TARGET, S_TARGET, NONE; //attack target, spell target, none
}
