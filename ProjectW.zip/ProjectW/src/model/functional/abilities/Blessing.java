package model.functional.abilities;

import model.card.HeroCard;
import model.functional.effects.Healling;

public class Blessing extends Abilities{

    public Blessing() {
    }

    @Override
    public void action(HeroCard target) {
        target.setEffect(new Healling());
        System.out.println(target.getName() + " got healling effect");
    }
   
}
