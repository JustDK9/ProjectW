package model.card.herocard;

import model.card.HeroCard;

public class ShadowAssassin extends HeroCard {
    public ShadowAssassin() {
        super("ShadowAssassin", 6, "A stealthy killer lurking in the shadows.", 7, 2);
    }
}