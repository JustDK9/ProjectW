package controller;

import java.util.logging.Level;
import java.util.logging.Logger;
import model.OnBoard;
import model.Player;
import model.type.TurnQueue;

public class Operation {

    private Player player1 = new Player();
    private Player player2 = new Player();
    DefaultGUI gui_player1 = new DefaultGUI(player1, player2);
    DefaultGUI gui_player2 = new DefaultGUI(player2, player1);
    
    public void getName() {
        player1.setName("Dang Khoa");
        player2.setName("Deng Khua");
    }

    public void openFrame() {
        gui_player1.run();
        gui_player2.run();
    }

    public void gameSetUp() {
        OnBoard.getBoard().getMainDeck().shuffle();
        for(int i = 0; i < 5; i++){           
            player1.getHandle().addCard(OnBoard.getBoard().getMainDeck().withdrawTopCard());
            player2.getHandle().addCard(OnBoard.getBoard().getMainDeck().withdrawTopCard());
        }
        player1.setQueue(TurnQueue.ACTIVE);
        player2.setQueue(TurnQueue.OPPONENT);
    }
    
    public static boolean updateSignal = true; //calling after active an button in default gui
    public static boolean endSignal = false;
    
    public void updating() {
        gui_player1.updating();
        System.out.println(player1.getHealthPoint());
        gui_player2.updating();
        System.out.println(player2.getHealthPoint());
        
        if(player1.getHealthPoint() * player2.getHealthPoint() <= 0){
            endSignal = true;
            player1.setQueue(TurnQueue.OPPONENT);
            player2.setQueue(TurnQueue.OPPONENT);
            gui_player1.dispose();
            gui_player2.dispose();
        }
    }

    public static void main(String[] args) {
        Operation op = new Operation();
        op.getName();
        op.gameSetUp();
        op.openFrame();
        while (!endSignal){
            if(updateSignal){
                op.updating(); 
                updateSignal = false;             
            }       
            try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {
                Logger.getLogger(Operation.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
