package model.type;

public enum SelectedPlace {
    A_TARGET, S_TARGET, SELECT, NONE, REMOVE; //attack target, spell target, none
}
