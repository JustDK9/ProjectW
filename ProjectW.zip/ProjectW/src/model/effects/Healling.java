package model.effects;

import model.card.HeroCard;

public class Healling extends Effects{

    public Healling() {
    }

    @Override
    public void action(HeroCard target) {
        if(target.getDefendPoint() < 10){
            target.setDefendPoint(target.getDefendPoint()+1);
            System.out.println(target.getName() + " was healed.");
        } else {
            System.out.println(target.getName() + " is full.");
        }
    }

}