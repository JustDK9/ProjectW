package model.card;

import model.card.herocard.ForestGuardianElf;
import model.card.equipmentcard.*;
import model.card.herocard.*;
import model.card.spellcard.*;

public class MainDeck extends Deck{
        public MainDeck(){
            super();
//            super.getDeck().add(new DoomHammer());
//            super.getDeck().add(new BladeOfVengeance());
            super.getDeck().add(new DualBlades());
//            super.getDeck().add(new FireSword());
            super.getDeck().add(new IronArmor());
            super.getDeck().add(new NaturalStaff());
            super.getDeck().add(new PoisonStinger());
//            super.getDeck().add(new SpecialSword());
//            super.getDeck().add(new SwordOfThePhoenix());
//            super.getDeck().add(new ThornMail());
            super.getDeck().add(new UnbreakableHelmet());

            super.getDeck().add(new DesertNomad());
            super.getDeck().add(new FireDragon());
            super.getDeck().add(new FireWarrior());
            super.getDeck().add(new ForestGuardian());
            super.getDeck().add(new ForestGuardianElf());
            super.getDeck().add(new FrostfireDragon());
            super.getDeck().add(new IceDragon());
            super.getDeck().add(new MoonlightElf());
            super.getDeck().add(new MountainTheif());
            super.getDeck().add(new OceanSorceress());
            super.getDeck().add(new ShadowAssassin());
            
            
            super.getDeck().add(new DeadlyTouch());
            super.getDeck().add(new Earthquake());
            super.getDeck().add(new Energetics());
            super.getDeck().add(new Gamblings());
            super.getDeck().add(new GodBlessMe());
            super.getDeck().add(new GreatCommander());
            super.getDeck().add(new GreedyHand());
            super.getDeck().add(new Purify());
            super.getDeck().add(new SpecialTricks());
            super.getDeck().add(new TalentedHealer());
            super.getDeck().add(new ThunderBolt());

        }

}