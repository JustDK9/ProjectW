/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.card.equipmentcard;

import model.card.EquipmentCard;
import model.card.HeroCard;
import model.effects.Poison;
import model.type.PassiveType;

/**
 *
 * @author mew3d
 */
public class PoisonStinger extends EquipmentCard{
    //name, price, desctiption, atk, def, type
    public PoisonStinger() {
        super("PoisonStinger", 2, "The toxic weapon can poisoning enermy.", 2, 1, PassiveType.ATTACK);
    }

    //poisoning enermy
    @Override
    public void active(HeroCard active, HeroCard opponent) {//enemy
        opponent.setEffect(new Poison());
        System.out.println(opponent.getName() + " was poisoned!");
    }
    
}
