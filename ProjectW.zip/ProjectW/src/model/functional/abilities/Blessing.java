package model.functional.abilities;

import model.card.HeroCard;

public class Blessing extends Abilities{

    public Blessing() {
    }

    @Override
    public void action(HeroCard target) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
   
}
