package model.functional.effects;

import model.card.HeroCard;

public class Healling extends Effects{

    public Healling() {
    }

    @Override
    public void action(HeroCard target) {
        target.setDefendPoint(target.getDefendPoint()+1);
        System.out.println(target.getName() + " was healed");
    }

}