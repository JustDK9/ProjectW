/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.card.spellcard;

import model.card.HeroCard;
import model.card.SpellCard;
import model.type.SpellTarget;

/**
 *
 * @author mew3d
 */
public class ThunderBolt extends SpellCard{

    public ThunderBolt(String name, int price, String desctiption, SpellTarget option) {
        super("ThunerBolt", 1, "Deal 3 dame to an enermy.", SpellTarget.OPPONENT);
    }

    @Override
    public void cast(HeroCard target) {
        target.setDefendPoint(target.getAttackPoint() - 3);
        System.out.println(target.getName() + " decreased 3 defend point.");
    }
    
}
